# KI Commander Vertrieb – Projektseite

> **Ziel:** Dem Vertriebsmitarbeiter zeigen, **was heute wichtig ist, warum es wichtig ist und welcher nächste Schritt empfohlen wird**.

**Stand:** 26.10.2026  
**Reifegrad:** MVP-/Demokonzept; produktive ERP-Integration nicht bestätigt

## Kundenproblem

Relevante Informationen liegen verteilt in ERP, Auftragsdaten, Kundenkommunikation, Kalender und Webseiten. Dadurch fehlen eine gemeinsame Sicht auf Prioritäten und nachvollziehbare nächste Schritte.

## Zielgruppe und Nutzen

**Zielgruppe:** Vertriebsmitarbeitende und ihre Teams.  
**Nutzen:** Weniger Suchaufwand, schnellere Orientierung, nachvollziehbare Empfehlungen und bessere Vorbereitung auf Kundenkontakte.

## MVP-Funktionen

1. Begrüßung: „Guten Morgen BTA Team“.
2. Dashboard mit Aufgaben, Prioritäten und Begründung.
3. Demo-Datenquelle für eingegangene Aufträge und ERP-Beispieldaten.
4. Demo-Kalender mit Notizen.
5. Prüfung von Kundenwebseiten auf relevante Neuigkeiten, soweit zulässig.
6. KI-basierte Handlungsempfehlungen mit Quellen und Unsicherheiten.
7. Kritische Aktionen nur nach ausdrücklicher menschlicher Freigabe.

## Architektur – logisch

```text
ERP-/EDI-Demodaten + Kundenwebseiten + Demo-Kalender
                    ↓
           Datenaufnahme / n8n
                    ↓
       Regeln, Validierung, Berechtigungen
                    ↓
              KI-Assistent
                    ↓
        Priorisierte Empfehlungen
                    ↓
      Mensch prüft und entscheidet
```

## Beispiel: EDI-Bestellung

- **Eingang:** Bestelldaten im vereinbarten Format.
- **Prüfung:** Pflichtfelder, Artikel, Menge, Termin, Dubletten.
- **KI-Beitrag:** Auffälligkeiten verständlich zusammenfassen und Rückfragen vorschlagen.
- **Freigabe:** Mitarbeitende prüfen Empfehlungen; keine automatische Auftragsänderung ohne Genehmigung.
- **Ergebnis:** Dokumentierter Vorgang mit Herkunft, Status und Entscheidung.

## Erfolgskriterien für einen Pilot

| Kennzahl | Prüfidee |
|---|---|
| Datenqualität | Anteil korrekt verarbeiteter Demo-Aufträge |
| Nachvollziehbarkeit | Empfehlungen mit Quelle und Begründung |
| Zeitersparnis | Bearbeitungszeit vor/nach Pilot vergleichen |
| Sicherheit | Keine nicht freigegebene Aktion |
| Nutzerakzeptanz | Feedback der Testpersonen |

## Nächste drei Schritte

- [ ] Einen kleinen, freigegebenen Demodatensatz und Soll-Ergebnisse festlegen
- [ ] Drei typische Vertriebsfälle inklusive Fehlerfällen durchtesten
- [ ] Pilotbericht mit Nutzen, Risiken, Kostenannahmen und Entscheidung erstellen

## Datenschutz und Integration

Produktive Kunden-/Unternehmensdaten nur mit Berechtigung verwenden. API-Schlüssel geheim halten. Rollenrechte, Protokollierung, Datenminimierung und Löschkonzept vor produktivem Einsatz definieren.

## Verknüpfungen

- [[04_Mensch_und_KI_byDesign]]
- [[05_Wissensmanagement_Agenten_QA]]
