# Wissensmanagement, Agenten & Quality Assurance

> **Prinzip:** Ein Skill bearbeitet eine Aufgabe → eine Prüfung bewertet das Ergebnis → ein Loop verbessert es → erst ein freigegebener Eintrag wird veröffentlicht.

**Stand:** 26.10.2026  
**Betriebsmodus:** Zunächst ausschließlich lesende Prüfungen; keine automatische Veröffentlichung

## Wissenslebenszyklus

```text
Quelle → Import → Klassifikation → Verknüpfung → QA-Prüfung
                                              ↓
                                      Menschliche Freigabe
                                              ↓
                                   Veröffentlichung / Export
                                              ↓
                                      Regelmäßige Kontrolle
```

## Agentenrollen

| Rolle | Aufgabe | Berechtigung im ersten Schritt |
|---|---|---|
| Wissensaufnahme-Agent | Neue Einträge und Metadaten erfassen | Lesend / Vorschläge |
| Verknüpfungs-Agent | Verwandte Themen und Projekte finden | Lesend / Vorschläge |
| QA-Agent | Status, Quellen, Dubletten und Aktualität prüfen | Nur lesend |
| Export-Agent | Freigegebene Inhalte für Markdown/JSON vorbereiten | Nach separater Freigabe |

## QA-Regeln

1. **Statuskonsistenz:** Veröffentlichungsstatus und Qualitätsstatus miteinander vergleichen.
2. **Quellen:** Fehlende, defekte und ungeeignete Quellen kennzeichnen.
3. **Verknüpfung:** Buzzwords, Deep Dives, Expertenthemen und Anwendungsfälle verbinden.
4. **Dubletten:** Identische und inhaltlich überlappende Einträge zur Prüfung markieren.
5. **Historie:** Veraltete Inhalte und abweichende Versionen hervorheben.
6. **Sicherheit:** Vertrauliche Daten, Kundendaten und personenbezogene Inhalte nicht ungeprüft exportieren.
7. **Freigabe:** Der Agent ändert keine Publikationsrechte oder veröffentlicht nicht selbst.

## Beispiel für einen Prüfeintrag

| Feld | Beispiel |
|---|---|
| Titel | KI & Ethik im KI-Lifecycle |
| Qualitätsstatus | Geprüft |
| Veröffentlichungsstatus | In Prüfung |
| Auffälligkeit | Status weichen voneinander ab |
| Aktion | Menschliche Sichtung vorschlagen, nicht selbst freigeben |

## n8n-Workflow – Zielbild

1. Notion-Einträge im erlaubten Bereich lesend abfragen.
2. Regeln auf Metadaten, Quellen und Links anwenden.
3. Prüfprotokoll mit Eintrags-ID, Problem und Empfehlung erstellen.
4. Prüfbericht im Dashboard zur Sichtung bereitstellen.
5. Erst nach expliziter Freigabe in einer **späteren Ausbaustufe** Schreibaktionen ermöglichen.

## Austausch zwischen LLMs

**Portables Standardformat:** Markdown für lesbare Seiten; JSON für strukturierte Metadaten. Jeden Export mit Titel, Version, Datum, Quelle, Lizenz-/Freigabestatus und Prüfergebnis dokumentieren.

## Nächste Schritte

- [ ] Notion-Eigenschaften für Qualität, Freigabe, Quelle und Prüfdatum vereinheitlichen
- [ ] QA-Agent mit zehn Testeinträgen ausschließlich lesend erproben
- [ ] Falsch-Positive prüfen und Regeln verbessern
- [ ] Vor einem Export Freigabe- und Datenschutzprüfung nachweisen

## Verknüpfungen

- [[01_Second_Brain_Dashboard]]
- [[02_KI_Portfolio]]
- [GitHub-Projekt](https://github.com/Nazan144/ki-second-brain-command-center)
