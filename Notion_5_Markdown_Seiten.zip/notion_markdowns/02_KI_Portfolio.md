# Mein KI-Portfolio

> **Leitidee:** Menschen bleiben verantwortlich; KI hilft, Wissen besser zu nutzen, Prozesse zu verbessern und fundierte Entscheidungen zu treffen.

**Stand:** 26.10.2026  
**Typ:** Portfolio-Übersicht

## Profil und Schwerpunkt

Mein Schwerpunkt liegt an der Schnittstelle von kaufmännischen Prozessen, ERP-Systemen, Wissensmanagement und praxisnaher KI. Mich interessiert insbesondere, wie sich KI sicher, nachvollziehbar und schrittweise in bestehende Unternehmensabläufe integrieren lässt.

## Projekte und Arbeitsproben

| Projekt | Ziel | Ergebnisse / Artefakte |
|---|---|---|
| KI Commander Vertrieb | Tagesprioritäten und nächste Schritte im Vertrieb sichtbar machen | MVP-Konzept, Demo-Datenquellen, Dashboard, Workflow |
| KI Second Brain | Wissen auffindbar, verknüpft und wiederverwendbar machen | Notion-Struktur, Command Center, Agentenregeln |
| Mensch & KI byDesign | Menschzentrierte Prozessoptimierung mit KI | Beratungsphilosophie, Website, Framework |
| LLM Memory Hub / Transfer | Wissen systematisch zwischen KI-Systemen übertragen | Export-/Import-Konzept, Super-Prompt, Projektarchiv |
| KI in der Cloud | Cloud-Modelle und Kundennutzen erklären | Kundenperspektive, Beratungsstrategie, Fallbeispiel |
| APIs, ERP und EDI | Sicheren Datenaustausch in Unternehmenssystemen planen | Begriffserklärungen, EDI-Pilotidee, Infografiken |
| SLMs & effiziente KI | Kleinere Modelle und Einsatzgrenzen verstehen | Deep Dive, Use Cases, Risiken |

## Fachgebiete

- Kaufmännische Steuerung, Rechnungswesen und Controlling
- ERP- und Warenwirtschaftsprozesse einschließlich EDI
- KI-Assistenten, Agenten, Workflows und Prompt Engineering
- Datenintegration, API-Sicherheit und Cloud-Architektur
- Wissensmanagement, Governance, Qualitätsprüfung und Evaluation
- Prozessoptimierung, Change Management und Mensch-KI-Zusammenarbeit

## Nachweis- und Qualitätsprinzip

Jede Arbeitsprobe sollte **Problem**, **Zielgruppe**, **Vorgehen**, **Ergebnis**, **Test**, **Grenzen** und **nächste Schritte** dokumentieren. Demo-Ergebnisse nicht als produktive Implementierung darstellen.

## Verknüpfungen

- [GitHub: Knowledge Command Center](https://github.com/Nazan144/ki-second-brain-command-center)
- [Second Brain Webseite](https://nazan-second-brain.ki-consultan-3592.chatgpt.site/)
- [[03_KI_Commander_Vertrieb]]
- [[04_Mensch_und_KI_byDesign]]

## Nächste Schritte

- [ ] Für jedes Projekt ein überprüfbares Ergebnis und einen Qualitätsstatus ergänzen
- [ ] Screenshots, Diagramme und freigegebene Demo-Dateien verlinken
- [ ] Veröffentlichbare von internen Arbeitsständen trennen
