# Mensch & KI byDesign – Beratungsstrategie

> **Zentrale Botschaft:** Wir ersetzen keine Mitarbeitenden oder bestehenden Unternehmenssysteme. Wir machen vorhandenes Wissen besser nutzbar, verbessern Arbeitsprozesse und unterstützen Menschen bei fundierten Entscheidungen.

**Stand:** 26.10.2026

## Haltung

Der Mensch ist der fachlich verantwortliche Prozessgestalter. KI ergänzt seine Arbeit, strukturiert Informationen und unterstützt Entscheidungen. Neue Muster und Arbeitsweisen dürfen im Change Management entstehen, ohne dass Verantwortung unklar wird.

## Fachlicher Fokus

- Rechnungswesen, Buchhaltung und Controlling
- Inventur, ERP- und Buchhaltungssysteme
- Systemadministration und betriebswirtschaftliche Konfigurationen
- Bereichsübergreifende kaufmännische Prozesse
- Sichere APIs, ERP-/EDI-Integration und KI in der Cloud

## Beratungsablauf

| Phase | Leitfrage | Ergebnis |
|---|---|---|
| 1. Verstehen | Welches Problem kostet Zeit oder erzeugt Fehler? | Ist-Prozess und Zielbild |
| 2. Priorisieren | Wo ist ein kleiner, messbarer Nutzen möglich? | Priorisierter Use Case |
| 3. Absichern | Welche Daten, Rechte und Risiken bestehen? | Sicherheits- und Freigabekonzept |
| 4. Pilotieren | Funktioniert die Lösung mit Testdaten? | MVP und Evaluation |
| 5. Verbessern | Was zeigen Messwerte und Nutzerfeedback? | Optimierter Workflow |
| 6. Skalieren | Wann ist ein breiterer Einsatz sinnvoll? | Entscheidungsgrundlage und Rollout-Plan |

## Kundenbeispiel: KI Commander Vertrieb

**Ausgangslage:** Aufträge, Kundeninformationen und Termine sind verteilt.  
**Lösungsidee:** Ein Assistent fasst relevante Ereignisse zusammen und empfiehlt nächste Schritte.  
**Menschliche Kontrolle:** Vertrieb und Fachverantwortliche prüfen kritische Entscheidungen.  
**Erwarteter Nutzen:** Überblick, Transparenz und weniger manuelle Recherche – im Pilot zu messen, nicht vorauszusetzen.

## Cloud-Strategie aus Kundensicht

Die Entscheidung zwischen lokalen, privaten, öffentlichen oder hybriden Betriebsmodellen richtet sich nach Datenschutz, Integrationsbedarf, Verfügbarkeit, Kosten und Kontrollanforderungen. Cloud ist kein Selbstzweck; die Architektur folgt dem Use Case.

## Grundsätze

1. Bestehende Systeme sinnvoll ergänzen statt reflexartig ersetzen.
2. Datenherkunft, Unsicherheiten und Zugriffsrechte sichtbar machen.
3. Fachliche Entscheidungen beim Menschen belassen.
4. Zunächst klein testen, Qualität messen und anschließend ausbauen.
5. Änderungen dokumentieren, kommunizieren und regelmäßig überprüfen.

## Nächster Workshop

- [ ] Einen konkreten Kundenprozess auswählen
- [ ] Ist-/Soll-Ablauf mit Verantwortlichkeiten darstellen
- [ ] Pilotmetriken, Schutzmaßnahmen und Entscheidungspunkt vereinbaren

## Webseite

[Mensch & KI byDesign](https://nazan-second-brain.ki-consultan-3592.chatgpt.site/mensch-ki.html)
